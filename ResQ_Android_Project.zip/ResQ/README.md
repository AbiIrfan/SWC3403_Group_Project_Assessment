# ResQ – Community Food Rescue (SWC3403/SWC3713)

Kotlin + Jetpack Compose + Firebase Firestore. Roles: Donor, Recipient, Volunteer collector. Languages: English / Bahasa Melayu.

## Setup (5 minutes)
1. Firebase Console -> Add project -> Add Android app, package name `com.resq.app`.
2. Download `google-services.json` and place it in `app/`.
3. Build -> Firestore Database -> Create database (test mode for the demo).
4. Open this folder in Android Studio, sync Gradle, run on emulator/phone (API 26+).

## Demo flow
Demo Donor: add food -> switch role (logout icon) -> Demo Recipient: search/filter, reserve + pick slot (request volunteer)
-> Demo Volunteer: accept, picked up, delivered -> Recipient: confirm received -> History on each role.

## Firestore data
- `users/{role_phone}`: name, role, phone, area, subType, idNumber, verified
- `listings/{id}`: food details, halal, allergens, expiry, status, recipient, volunteer, pickupTime, timestamps
Status: LISTED > RESERVED > VOLUNTEER_ASSIGNED > PICKED_UP > DELIVERED > COMPLETED (or CANCELLED / EXPIRED)
