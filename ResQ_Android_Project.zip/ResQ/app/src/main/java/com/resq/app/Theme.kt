package com.resq.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = lightColorScheme(
    primary = Color(0xFF2E7D32), onPrimary = Color.White,
    primaryContainer = Color(0xFFDFF3E0), onPrimaryContainer = Color(0xFF12391A),
    secondary = Color(0xFFEF6C00), secondaryContainer = Color(0xFFFFE9D6),
    background = Color(0xFFFAFAF7), surface = Color.White, surfaceVariant = Color(0xFFF1F3EE)
)

@Composable fun ResQTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
