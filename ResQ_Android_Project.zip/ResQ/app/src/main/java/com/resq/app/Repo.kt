package com.resq.app

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/** All Firestore access lives here so it is easy to explain during Q&A. */
object Repo {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val col get() = db.collection("listings")

    fun listings(): Flow<List<Listing>> = callbackFlow {
        val reg = col.addSnapshotListener { s, e ->
            if (e != null) { close(e); return@addSnapshotListener }
            if (s != null) trySend(s.documents.mapNotNull { d -> d.toObject(Listing::class.java)?.copy(id = d.id) })
        }
        awaitClose { reg.remove() }
    }

    suspend fun saveUser(u: AppUser) { db.collection("users").document(u.id).set(u).await() }
    suspend fun add(l: Listing) { col.add(l).await() }
    fun update(id: String, updates: Map<String, Any>) { col.document(id).update(updates) }

    /** Atomic status change: succeeds only if the document is still in status [from] (prevents double reservation). */
    suspend fun transition(id: String, from: String, updates: Map<String, Any>): Boolean = try {
        db.runTransaction { t ->
            val ref = col.document(id)
            if (t.get(ref).getString("status") != from) throw IllegalStateException("conflict")
            t.update(ref, updates)
            null
        }.await()
        true
    } catch (e: Exception) { false }

    suspend fun seedIfEmpty() {
        for (u in listOf(DEMO_DONOR, DEMO_RECIPIENT, DEMO_VOLUNTEER)) saveUser(u)
        if (!col.limit(1).get().await().isEmpty) return
        val n = System.currentTimeMillis(); val h = 3_600_000L
        fun l(t: String, d: String, c: String, q: Int, a: String, ad: String, dn: String, dt: String, halal: Boolean,
              al: String, exp: Long, donorId: String = "DONOR_seed") =
            Listing(title = t, description = d, category = c, quantity = q, area = a, address = ad, donorId = donorId,
                donorName = dn, donorType = dt, halal = halal, allergens = al, preparedAt = n - h, expiryAt = n + exp * h,
                imageUrl = "", status = "LISTED", createdAt = n, updatedAt = n)
        listOf(
            l("Nasi lemak bungkus", "Freshly cooked, unsold after lunch", "COOKED", 30, "Setapak", "Jalan Genting Klang", DEMO_DONOR.name, "Restaurant", true, "Peanuts, anchovies", 3, DEMO_DONOR.id),
            l("Nasi briyani ayam", "Catering leftovers, sealed boxes", "COOKED", 20, "Brickfields", "Jalan Tun Sambanthan", DEMO_DONOR.name, "Restaurant", true, "Milk, nuts", 2, DEMO_DONOR.id),
            l("Roti & bun (unsold)", "Baked this morning", "BAKERY", 40, "Bukit Bintang", "Jalan Alor", "Bakeri Pagi Baru", "Bakery", true, "Gluten, milk, eggs", 12),
            l("Sayur campur", "Cabbage, carrot, long beans", "PRODUCE", 20, "Kepong", "Pasar Malam Kepong", "Pak Din (pasar malam)", "Pasar malam seller", true, "None", 24),
            l("Canned sardines & biscuits", "Near best-before date", "PACKAGED", 50, "Cheras", "Kolej Kediaman Cheras", "Kafeteria Kolej Cheras", "Hostel cafeteria", true, "Fish, gluten", 48),
            l("Teh tarik & kopi", "Cold bottled drinks", "DRINKS", 25, "Wangsa Maju", "Jalan Wangsa 3", "Puan Rohani", "Household", true, "Milk", 6),
            l("Kuih-muih campur", "Assorted traditional kuih", "BAKERY", 35, "Bangsar", "Pasar Malam Bangsar", "Kak Mah", "Pasar malam seller", true, "Coconut, gluten", 8),
            l("Epal & pisang", "Slightly bruised but fresh", "PRODUCE", 18, "Sentul", "Jalan Sentul Pasar", "Encik Faizal", "Household", true, "None", 24)
        ).forEach { add(it) }
    }
}
