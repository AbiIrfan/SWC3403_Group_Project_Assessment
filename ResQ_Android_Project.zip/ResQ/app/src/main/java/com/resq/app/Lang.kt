package com.resq.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf

val LocalLang = compositionLocalOf { "en" }

@Composable fun tr(en: String, ms: String) = if (LocalLang.current == "ms") ms else en
@Composable fun Category.label() = tr(en, ms)
@Composable fun roleLabel(r: String) = when (r) {
    "DONOR" -> tr("Donor", "Penderma")
    "RECIPIENT" -> tr("Recipient", "Penerima")
    else -> tr("Volunteer", "Sukarelawan")
}
@Composable fun Status.label() = when (this) {
    Status.LISTED -> tr("Available", "Tersedia")
    Status.RESERVED -> tr("Reserved", "Ditempah")
    Status.VOLUNTEER_ASSIGNED -> tr("Volunteer assigned", "Sukarelawan ditugaskan")
    Status.PICKED_UP -> tr("Picked up", "Telah diambil")
    Status.DELIVERED -> tr("Delivered", "Dihantar")
    Status.COMPLETED -> tr("Completed", "Selesai")
    Status.CANCELLED -> tr("Cancelled", "Dibatalkan")
    Status.EXPIRED -> tr("Expired", "Tamat tempoh")
}
