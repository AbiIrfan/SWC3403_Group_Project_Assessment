package com.resq.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class AppVM(app: Application) : AndroidViewModel(app) {
    var user by mutableStateOf<AppUser?>(null); private set
    var lang by mutableStateOf("en")
    var listings by mutableStateOf(listOf<Listing>()); private set
    var message by mutableStateOf<String?>(null)
    var tab by mutableStateOf(0)
    private var prev = mapOf<String, String>()
    private val ctx = app.applicationContext

    private fun t(en: String, ms: String) = pick(lang, en, ms)
    fun say(en: String, ms: String) { message = t(en, ms) }

    init {
        viewModelScope.launch {
            try { Repo.seedIfEmpty() } catch (e: Exception) {
                say("Cannot reach database. Check internet and Firebase setup.", "Tidak dapat capai pangkalan data. Semak internet dan tetapan Firebase.")
            }
            Repo.listings().catch {
                say("Live updates stopped: ${it.message}", "Kemaskini langsung terhenti: ${it.message}")
            }.collect { onData(it) }
        }
    }

    private fun onData(list: List<Listing>) {
        val now = System.currentTimeMillis()
        list.filter { it.status == "LISTED" && it.expiryAt < now }
            .forEach { Repo.update(it.id, mapOf("status" to "EXPIRED", "updatedAt" to now)) }
        val u = user
        if (u != null && prev.isNotEmpty()) list.forEach { l ->
            val old = prev[l.id]
            val text = when {
                old == null && u.role == "RECIPIENT" && l.status == "LISTED" && l.area == u.area ->
                    t("New food in ${l.area}: ${l.title}", "Makanan baharu di ${l.area}: ${l.title}")
                old != null && old != l.status && u.role == "VOLUNTEER" && l.status == "RESERVED" && l.needsVolunteer ->
                    t("New pickup task: ${l.title}", "Tugasan baharu: ${l.title}")
                old != null && old != l.status && (l.donorId == u.id || l.recipientId == u.id || l.volunteerId == u.id) ->
                    t("${l.title}: ${l.status.replace('_', ' ').lowercase()}", "${l.title}: status ${l.status.replace('_', ' ').lowercase()}")
                else -> null
            }
            if (text != null) Notifier.show(ctx, l.id.hashCode(), "ResQ", text)
        }
        prev = list.associate { it.id to it.status }
        listings = list
    }

    fun login(u: AppUser) { user = u; tab = 0; viewModelScope.launch { try { Repo.saveUser(u) } catch (_: Exception) {} } }
    fun logout() { user = null }
    fun toggleLang() { lang = if (lang == "en") "ms" else "en" }

    fun addListing(l: Listing) = viewModelScope.launch {
        try {
            Repo.add(l); tab = 0
            say("Food listing published", "Senarai makanan diterbitkan")
        } catch (e: Exception) { say("Could not publish. Check your connection.", "Gagal diterbitkan. Semak sambungan anda.") }
    }

    private fun move(l: Listing, to: String, extra: Map<String, Any> = emptyMap(), okEn: String, okMs: String) =
        viewModelScope.launch {
            val ok = Repo.transition(l.id, l.status, extra + mapOf("status" to to, "updatedAt" to System.currentTimeMillis()))
            if (ok) say(okEn, okMs) else say("This item was just updated by someone else.", "Item ini baru dikemas kini oleh pengguna lain.")
        }

    fun reserve(l: Listing, slot: Long, vol: Boolean) {
        val u = user ?: return
        if (!u.verified) { say("Only verified recipients can reserve food.", "Hanya penerima disahkan boleh menempah."); return }
        move(l, "RESERVED", mapOf("recipientId" to u.id, "recipientName" to u.name, "pickupTime" to slot, "needsVolunteer" to vol),
            "Reserved! Pickup at ${fmt(slot)}", "Berjaya ditempah! Ambilan pada ${fmt(slot)}")
    }
    fun release(l: Listing) = move(l, "LISTED", mapOf("recipientId" to "", "recipientName" to "", "pickupTime" to 0L, "needsVolunteer" to false),
        "Reservation cancelled; food is available again", "Tempahan dibatalkan; makanan tersedia semula")
    fun cancel(l: Listing) = move(l, "CANCELLED", okEn = "Listing cancelled", okMs = "Senarai dibatalkan")
    fun accept(l: Listing) { val u = user ?: return
        move(l, "VOLUNTEER_ASSIGNED", mapOf("volunteerId" to u.id, "volunteerName" to u.name), "Task accepted", "Tugasan diterima") }
    fun pickedUp(l: Listing) = move(l, "PICKED_UP", okEn = "Marked as picked up", okMs = "Ditanda telah diambil")
    fun delivered(l: Listing) = move(l, "DELIVERED", okEn = "Marked as delivered", okMs = "Ditanda telah dihantar")
    fun complete(l: Listing) = move(l, "COMPLETED", okEn = "Collection completed. Thank you!", okMs = "Pengambilan selesai. Terima kasih!")
}
