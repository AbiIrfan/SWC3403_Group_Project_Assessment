package com.resq.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ResQApp(vm: AppVM) {
    CompositionLocalProvider(LocalLang provides vm.lang) {
        val u = vm.user
        if (u == null) WelcomeScreen(vm) else MainScreen(vm, u)
    }
}

// ---------------------------------------------------------------- Welcome / login / register
@Composable
fun WelcomeScreen(vm: AppVM) {
    val lang = vm.lang
    var role by remember { mutableStateOf("DONOR") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var area by remember { mutableStateOf(AREAS[0]) }
    var sub by remember { mutableStateOf("") }
    var idNo by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(mapOf<String, String>()) }
    val subOptions = when (role) { "DONOR" -> DONOR_TYPES; "RECIPIENT" -> RECIPIENT_TYPES; else -> VOLUNTEER_TYPES }
    val subSel = if (sub in subOptions) sub else subOptions[0]

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { vm.toggleLang() }) { Icon(Icons.Default.Language, null); Text(if (lang == "en") " Bahasa Melayu" else " English") }
        }
        Text("🍲 ResQ", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(tr("Rescue surplus food. Feed the community.", "Selamatkan lebihan makanan. Beri makan komuniti."), style = MaterialTheme.typography.bodyLarge)

        Text(tr("Quick demo login", "Log masuk demo pantas"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Button(onClick = { vm.login(DEMO_DONOR) }, Modifier.fillMaxWidth()) { Text(tr("Donor – ", "Penderma – ") + DEMO_DONOR.name) }
        Button(onClick = { vm.login(DEMO_RECIPIENT) }, Modifier.fillMaxWidth()) { Text(tr("Recipient – ", "Penerima – ") + DEMO_RECIPIENT.name) }
        Button(onClick = { vm.login(DEMO_VOLUNTEER) }, Modifier.fillMaxWidth()) { Text(tr("Volunteer – ", "Sukarelawan – ") + DEMO_VOLUNTEER.name) }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Text(tr("Or register", "Atau daftar"), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("DONOR", "RECIPIENT", "VOLUNTEER").forEach { r ->
                FilterChip(selected = role == r, onClick = { role = r; err = emptyMap() }, label = { Text(roleLabel(r)) })
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text(tr("Full name / organisation", "Nama penuh / organisasi")) }, isError = "name" in err, supportingText = { err["name"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(phone, { phone = it.filter(Char::isDigit) }, label = { Text(tr("Phone (e.g. 0123456789)", "Telefon (cth. 0123456789)")) }, isError = "phone" in err, supportingText = { err["phone"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Dropdown(tr("Area (Kuala Lumpur)", "Kawasan (Kuala Lumpur)"), opts(AREAS), area, { area = it })
        Dropdown(tr("Type", "Jenis"), opts(subOptions), subSel, { sub = it })
        if (role == "RECIPIENT") OutlinedTextField(idNo, { idNo = it.trim() }, label = { Text(tr("IC / matric / organisation ID (verification)", "No. KP / matrik / ID organisasi (pengesahan)")) }, isError = "id" in err, supportingText = { err["id"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            val e = mutableMapOf<String, String>()
            if (name.trim().length < 3) e["name"] = pick(lang, "Enter at least 3 characters", "Masukkan sekurang-kurangnya 3 aksara")
            if (!Regex("^01\\d{8,9}$").matches(phone)) e["phone"] = pick(lang, "Enter a valid Malaysian mobile number", "Masukkan nombor telefon Malaysia yang sah")
            if (role == "RECIPIENT" && !(Regex("^\\d{12}$").matches(idNo) || Regex("^[A-Za-z0-9]{6,15}$").matches(idNo)))
                e["id"] = pick(lang, "Verification failed: use a 12-digit IC or a 6–15 character matric/organisation ID", "Pengesahan gagal: guna 12 digit KP atau ID matrik/organisasi 6–15 aksara")
            err = e
            if (e.isEmpty()) vm.login(AppUser("${role}_$phone", name.trim(), role, phone, area, subSel, idNo, true))
        }, Modifier.fillMaxWidth()) { Text(tr("Register & continue", "Daftar & teruskan")) }
    }
}

// ---------------------------------------------------------------- Main scaffold
private data class TabItem(val icon: ImageVector, val en: String, val ms: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: AppVM, u: AppUser) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    val tabs = when (u.role) {
        "DONOR" -> listOf(TabItem(Icons.Default.Home, "My listings", "Senarai saya"), TabItem(Icons.Default.AddCircle, "Add food", "Tambah"), TabItem(Icons.Default.History, "History", "Sejarah"))
        "RECIPIENT" -> listOf(TabItem(Icons.Default.Search, "Find food", "Cari"), TabItem(Icons.Default.Bookmarks, "Reservations", "Tempahan"), TabItem(Icons.Default.History, "History", "Sejarah"))
        else -> listOf(TabItem(Icons.Default.DeliveryDining, "Open tasks", "Tugasan"), TabItem(Icons.Default.Assignment, "My tasks", "Tugas saya"), TabItem(Icons.Default.History, "History", "Sejarah"))
    }
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Column { Text("🍲 ResQ", fontWeight = FontWeight.Bold); Text("${roleLabel(u.role)} • ${u.name}", style = MaterialTheme.typography.bodySmall) } },
                actions = {
                    TextButton(onClick = { vm.toggleLang() }) { Text(if (vm.lang == "en") "BM" else "EN") }
                    IconButton(onClick = { vm.logout() }) { Icon(Icons.AutoMirrored.Filled.Logout, tr("Switch role / log out", "Tukar peranan / log keluar")) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = vm.tab == i, onClick = { vm.tab = i }, icon = { Icon(t.icon, null) }, label = { Text(tr(t.en, t.ms)) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (u.role) {
                "DONOR" -> when (vm.tab) { 0 -> DonorListings(vm, u); 1 -> AddListingScreen(vm, u); else -> HistoryScreen(vm, u) }
                "RECIPIENT" -> when (vm.tab) { 0 -> BrowseScreen(vm); 1 -> ReservationsScreen(vm, u); else -> HistoryScreen(vm, u) }
                else -> when (vm.tab) { 0 -> OpenTasksScreen(vm); 1 -> MyTasksScreen(vm, u); else -> HistoryScreen(vm, u) }
            }
        }
    }
}

// ---------------------------------------------------------------- Donor
@Composable
fun DonorListings(vm: AppVM, u: AppUser) {
    val mine = vm.listings.filter { it.donorId == u.id && it.status in ACTIVE }.sortedByDescending { it.createdAt }
    CardList(mine, tr("No active listings. Tap “Add food” to share surplus food.", "Tiada senarai aktif. Tekan “Tambah” untuk berkongsi makanan.")) { l ->
        if (l.status == "LISTED" || l.status == "RESERVED")
            OutlinedButton(onClick = { vm.cancel(l) }) { Text(tr("Cancel listing", "Batal senarai")) }
    }
}

@Composable
fun AddListingScreen(vm: AppVM, u: AppUser) {
    val lang = vm.lang
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("COOKED") }
    var qty by remember { mutableStateOf("") }
    var area by remember { mutableStateOf(u.area.ifBlank { AREAS[0] }) }
    var address by remember { mutableStateOf("") }
    var halal by remember { mutableStateOf(true) }
    var allergens by remember { mutableStateOf("") }
    var hours by remember { mutableStateOf("3") }
    var photo by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(mapOf<String, String>()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(tr("Share surplus food", "Kongsi lebihan makanan"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, label = { Text(tr("Food name", "Nama makanan")) }, isError = "title" in err, supportingText = { err["title"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(desc, { desc = it }, label = { Text(tr("Description (optional)", "Keterangan (pilihan)")) }, modifier = Modifier.fillMaxWidth())
        Dropdown(tr("Category", "Kategori"), Category.values().map { it.name to (if (lang == "ms") it.ms else it.en) }, cat, { cat = it })
        OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text(tr("Quantity (portions)", "Kuantiti (bahagian)")) }, isError = "qty" in err, supportingText = { err["qty"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Dropdown(tr("Collection area", "Kawasan pengambilan"), opts(AREAS), area, { area = it })
        OutlinedTextField(address, { address = it }, label = { Text(tr("Pickup address", "Alamat ambilan")) }, isError = "address" in err, supportingText = { err["address"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth())
        Dropdown(tr("Safe to collect within", "Selamat diambil dalam"), listOf("1", "2", "3", "4", "6", "12", "24", "48").map { it to "$it " + pick(lang, "hours", "jam") }, hours, { hours = it }, err["hours"])
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(halal, { halal = it }); Text("  " + tr("Halal", "Halal"))
        }
        OutlinedTextField(allergens, { allergens = it }, label = { Text(tr("Allergens (e.g. nuts, milk)", "Alergen (cth. kacang, susu)")) }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(photo, { photo = it.trim() }, label = { Text(tr("Photo URL (optional)", "URL gambar (pilihan)")) }, isError = "photo" in err, supportingText = { err["photo"]?.let { Text(it) } }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            val e = mutableMapOf<String, String>()
            val q = qty.toIntOrNull()
            if (title.trim().length < 3) e["title"] = pick(lang, "Enter at least 3 characters", "Masukkan sekurang-kurangnya 3 aksara")
            if (q == null || q < 1 || q > 500) e["qty"] = pick(lang, "Enter a quantity between 1 and 500", "Masukkan kuantiti antara 1 dan 500")
            if (address.isBlank()) e["address"] = pick(lang, "Pickup address is required", "Alamat ambilan diperlukan")
            if (cat == "COOKED" && hours.toInt() > 4) e["hours"] = pick(lang, "Cooked food must be collected within 4 hours for safety", "Makanan masak mesti diambil dalam 4 jam demi keselamatan")
            if (photo.isNotBlank() && !photo.startsWith("http")) e["photo"] = pick(lang, "Photo link must start with http", "Pautan gambar mesti bermula dengan http")
            err = e
            if (e.isEmpty()) {
                val now = System.currentTimeMillis()
                vm.addListing(Listing(title = title.trim(), description = desc.trim(), category = cat, quantity = q!!, area = area, address = address.trim(),
                    donorId = u.id, donorName = u.name, donorType = u.subType, halal = halal, allergens = allergens.trim(), preparedAt = now,
                    expiryAt = now + hours.toLong() * 3_600_000L, imageUrl = photo, status = "LISTED", createdAt = now, updatedAt = now))
                title = ""; desc = ""; qty = ""; address = ""; allergens = ""; photo = ""
            }
        }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text(tr("Publish listing", "Terbitkan senarai")) }
    }
}

// ---------------------------------------------------------------- Recipient
@Composable
fun BrowseScreen(vm: AppVM) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("ALL") }
    var area by remember { mutableStateOf("ALL") }
    var reserving by remember { mutableStateOf<Listing?>(null) }
    val now = System.currentTimeMillis()
    val items = vm.listings.filter {
        it.status == "LISTED" && it.expiryAt > now && (cat == "ALL" || it.category == cat) && (area == "ALL" || it.area == area) &&
            (q.isBlank() || listOf(it.title, it.description, it.donorName, it.area).any { s -> s.contains(q, true) })
    }.sortedBy { it.expiryAt }

    CardList(items, tr("No food matches your search right now.", "Tiada makanan sepadan buat masa ini."), header = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(q, { q = it }, label = { Text(tr("Search food, donor or area", "Cari makanan, penderma atau kawasan")) },
                leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(cat == "ALL", { cat = "ALL" }, { Text(tr("All", "Semua")) }) }
                items(Category.values().toList()) { c -> FilterChip(cat == c.name, { cat = c.name }, { Text(c.emoji + " " + c.label()) }) }
            }
            Dropdown(tr("Collection area", "Kawasan pengambilan"), listOf("ALL" to tr("All areas", "Semua kawasan")) + opts(AREAS), area, { area = it })
        }
    }) { l -> Button(onClick = { reserving = l }) { Text(tr("Reserve", "Tempah")) } }

    reserving?.let { l -> ReserveDialog(l, onDismiss = { reserving = null }) { slot, vol -> vm.reserve(l, slot, vol); reserving = null } }
}

@Composable
fun ReserveDialog(l: Listing, onDismiss: () -> Unit, onConfirm: (Long, Boolean) -> Unit) {
    val lang = LocalLang.current
    val now = remember { System.currentTimeMillis() }
    val slots = remember {
        val step = 30 * 60_000L; var t = (now / step + 1) * step
        val out = mutableListOf<Long>(); while (t <= l.expiryAt && out.size < 8) { out += t; t += step }; out
    }
    var slot by remember { mutableStateOf(slots.firstOrNull()?.toString() ?: "") }
    var vol by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(tr("Reserve & schedule pickup", "Tempah & jadualkan ambilan")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l.title, fontWeight = FontWeight.Bold)
                if (slots.isEmpty()) Text(tr("No pickup slot left before this food expires.", "Tiada slot ambilan sebelum makanan tamat tempoh."), color = MaterialTheme.colorScheme.error)
                else Dropdown(tr("Pickup time", "Masa ambilan"), slots.map { it.toString() to fmt(it) }, slot, { slot = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(vol, { vol = it }); Text(pick(lang, "Request a volunteer to deliver", "Minta sukarelawan menghantar"))
                }
            }
        },
        confirmButton = { Button(onClick = { onConfirm(slot.toLong(), vol) }, enabled = slots.isNotEmpty()) { Text(tr("Confirm", "Sahkan")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Back", "Kembali")) } })
}

@Composable
fun ReservationsScreen(vm: AppVM, u: AppUser) {
    val mine = vm.listings.filter { it.recipientId == u.id && it.status in ACTIVE }.sortedBy { it.pickupTime }
    CardList(mine, tr("No active reservations. Find food in the first tab.", "Tiada tempahan aktif. Cari makanan di tab pertama.")) { l ->
        val self = !l.needsVolunteer
        when {
            l.status == "RESERVED" && self -> {
                Button(onClick = { vm.pickedUp(l) }) { Text(tr("Mark picked up", "Tanda telah diambil")) }
                OutlinedButton(onClick = { vm.release(l) }) { Text(tr("Cancel", "Batal")) }
            }
            l.status == "RESERVED" -> OutlinedButton(onClick = { vm.release(l) }) { Text(tr("Cancel", "Batal")) }
            (l.status == "PICKED_UP" && self) || l.status == "DELIVERED" ->
                Button(onClick = { vm.complete(l) }) { Text(tr("Confirm received", "Sahkan diterima")) }
        }
    }
}

// ---------------------------------------------------------------- Volunteer
@Composable
fun OpenTasksScreen(vm: AppVM) {
    var area by remember { mutableStateOf("ALL") }
    val items = vm.listings.filter { it.status == "RESERVED" && it.needsVolunteer && (area == "ALL" || it.area == area) }.sortedBy { it.pickupTime }
    CardList(items, tr("No delivery requests right now.", "Tiada permintaan penghantaran buat masa ini."), header = {
        Dropdown(tr("Collection area", "Kawasan pengambilan"), listOf("ALL" to tr("All areas", "Semua kawasan")) + opts(AREAS), area, { area = it })
    }) { l -> Button(onClick = { vm.accept(l) }) { Text(tr("Accept task", "Terima tugasan")) } }
}

@Composable
fun MyTasksScreen(vm: AppVM, u: AppUser) {
    val mine = vm.listings.filter { it.volunteerId == u.id && (it.status == "VOLUNTEER_ASSIGNED" || it.status == "PICKED_UP") }.sortedBy { it.pickupTime }
    CardList(mine, tr("You have no active tasks.", "Anda tiada tugasan aktif.")) { l ->
        if (l.status == "VOLUNTEER_ASSIGNED") Button(onClick = { vm.pickedUp(l) }) { Text(tr("Mark picked up", "Tanda telah diambil")) }
        else Button(onClick = { vm.delivered(l) }) { Text(tr("Mark delivered", "Tanda telah dihantar")) }
    }
}

// ---------------------------------------------------------------- History (all roles)
@Composable
fun HistoryScreen(vm: AppVM, u: AppUser) {
    val done = vm.listings.filter {
        (it.donorId == u.id || it.recipientId == u.id || it.volunteerId == u.id) &&
            (it.status in FINISHED || (u.role == "VOLUNTEER" && it.status == "DELIVERED"))
    }.sortedByDescending { it.updatedAt }
    val completed = done.count { it.status == "COMPLETED" || it.status == "DELIVERED" }
    CardList(done, tr("No history yet.", "Belum ada sejarah."), header = {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Text("✅ " + tr("Completed rescues: ", "Penyelamatan selesai: ") + completed, Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
        }
    })
}
