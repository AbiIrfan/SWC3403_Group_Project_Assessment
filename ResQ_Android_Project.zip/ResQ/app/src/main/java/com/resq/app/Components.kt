package com.resq.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dropdown(label: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit, error: String? = null) {
    var open by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { open = it }, modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = options.firstOrNull { it.first == selected }?.second ?: "", onValueChange = {}, readOnly = true,
            label = { Text(label) }, isError = error != null, supportingText = { error?.let { Text(it) } },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(open) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (k, v) -> DropdownMenuItem(text = { Text(v) }, onClick = { onSelect(k); open = false }) }
        }
    }
}

fun opts(list: List<String>) = list.map { it to it }

@Composable
fun StatusChip(s: Status) {
    val color = when (s) {
        Status.LISTED -> Color(0xFF2E7D32); Status.RESERVED -> Color(0xFFEF6C00)
        Status.VOLUNTEER_ASSIGNED -> Color(0xFF1565C0); Status.PICKED_UP -> Color(0xFF6A1B9A)
        Status.DELIVERED -> Color(0xFF00838F); Status.COMPLETED -> Color(0xFF1B5E20)
        Status.CANCELLED -> Color(0xFF757575); Status.EXPIRED -> Color(0xFFC62828)
    }
    Text(s.label(), color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun ListingCard(l: Listing, actions: @Composable RowScope.() -> Unit = {}) {
    val cat = l.cat()
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column {
            if (l.imageUrl.isNotBlank())
                AsyncImage(model = l.imageUrl, contentDescription = l.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(140.dp))
            else
                Box(Modifier.fillMaxWidth().height(90.dp).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    Text(cat.emoji, fontSize = 44.sp)
                }
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(l.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusChip(l.st())
                }
                Text("${l.donorName} • ${l.donorType}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (l.description.isNotBlank()) Text(l.description, style = MaterialTheme.typography.bodyMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                    Text(" ${l.area} – ${l.address}", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                    Text(" " + tr("Collect before ", "Ambil sebelum ") + fmt(l.expiryAt), style = MaterialTheme.typography.bodySmall)
                }
                Text("${cat.label()} • ${l.quantity} " + tr("portions", "bahagian") + " • " +
                    (if (l.halal) "Halal" else tr("Not halal-certified", "Tidak diperakui halal")), style = MaterialTheme.typography.bodySmall)
                if (l.allergens.isNotBlank()) Text("⚠ " + tr("Allergens: ", "Alergen: ") + l.allergens, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB71C1C))
                if (l.pickupTime > 0) Text(tr("Pickup slot: ", "Slot ambilan: ") + fmt(l.pickupTime), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                if (l.recipientName.isNotBlank()) Text(tr("Recipient: ", "Penerima: ") + l.recipientName, style = MaterialTheme.typography.bodySmall)
                if (l.volunteerName.isNotBlank()) Text(tr("Volunteer: ", "Sukarelawan: ") + l.volunteerName, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
            }
        }
    }
}

@Composable
fun CardList(items: List<Listing>, empty: String, header: (@Composable () -> Unit)? = null, actions: @Composable RowScope.(Listing) -> Unit = {}) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        if (header != null) item { header() }
        if (items.isEmpty()) item {
            Text(empty, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(items, key = { it.id }) { l -> ListingCard(l) { actions(l) } }
    }
}
