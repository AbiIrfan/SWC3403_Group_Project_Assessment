package com.resq.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Status { LISTED, RESERVED, VOLUNTEER_ASSIGNED, PICKED_UP, DELIVERED, COMPLETED, CANCELLED, EXPIRED }

enum class Category(val en: String, val ms: String, val emoji: String) {
    COOKED("Cooked meals", "Makanan masak", "🍛"),
    BAKERY("Bakery", "Roti & kuih", "🥖"),
    PRODUCE("Fruit & vegetables", "Buah & sayur", "🥬"),
    PACKAGED("Packaged food", "Makanan berbungkus", "🥫"),
    DRINKS("Drinks", "Minuman", "🧃")
}

val AREAS = listOf("Bukit Bintang", "Cheras", "Kepong", "Setapak", "Wangsa Maju", "Bangsar", "Brickfields", "Sentul", "Titiwangsa", "Segambut")
val DONOR_TYPES = listOf("Restaurant", "Bakery", "Hostel cafeteria", "Pasar malam seller", "Household")
val RECIPIENT_TYPES = listOf("Student", "B40 family", "Shelter / rumah kebajikan", "Surau / mosque programme", "Other individual")
val VOLUNTEER_TYPES = listOf("Student volunteer", "Community volunteer")
val ACTIVE = setOf("LISTED", "RESERVED", "VOLUNTEER_ASSIGNED", "PICKED_UP", "DELIVERED")
val FINISHED = setOf("COMPLETED", "CANCELLED", "EXPIRED")

/** Firestore collection "users". role = DONOR | RECIPIENT | VOLUNTEER. */
data class AppUser(
    val id: String = "", val name: String = "", val role: String = "DONOR", val phone: String = "",
    val area: String = "", val subType: String = "", val idNumber: String = "", val verified: Boolean = true
)

/** Firestore collection "listings". One document tracks the whole food-rescue lifecycle. */
data class Listing(
    val id: String = "", val title: String = "", val description: String = "", val category: String = "COOKED",
    val quantity: Int = 1, val area: String = "", val address: String = "",
    val donorId: String = "", val donorName: String = "", val donorType: String = "",
    val halal: Boolean = true, val allergens: String = "", val preparedAt: Long = 0, val expiryAt: Long = 0,
    val imageUrl: String = "", val status: String = "LISTED",
    val recipientId: String = "", val recipientName: String = "", val pickupTime: Long = 0,
    val needsVolunteer: Boolean = false, val volunteerId: String = "", val volunteerName: String = "",
    val createdAt: Long = 0, val updatedAt: Long = 0
)

fun Listing.st() = Status.valueOf(status)
fun Listing.cat() = Category.valueOf(category)
fun fmt(ms: Long): String = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(ms))
fun pick(lang: String, en: String, ms: String) = if (lang == "ms") ms else en

val DEMO_DONOR = AppUser("DONOR_0123456789", "Restoran Sri Setapak", "DONOR", "0123456789", "Setapak", "Restaurant")
val DEMO_RECIPIENT = AppUser("RECIPIENT_0111111111", "Aisyah binti Rahman", "RECIPIENT", "0111111111", "Setapak", "Student", "020304101234", true)
val DEMO_VOLUNTEER = AppUser("VOLUNTEER_0122222222", "Hafiz Ismail", "VOLUNTEER", "0122222222", "Setapak", "Community volunteer")
